package com.capsilon.capsilonbox.service;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capsilon.capsilonbox.entity.FileEntity;
import com.capsilon.capsilonbox.exception.FileHandlerTechnicalException;
import com.capsilon.capsilonbox.model.FileModel;
import com.capsilon.capsilonbox.repository.FileHandlerRepository;

@Service
public class FileServiceImpl implements FileService {

	private static final Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);

	@Autowired
	private FileHandlerRepository fileRepository;

	@Override
	public FileModel uploadFile(FileModel fileModel) {
		ModelMapper mapper = getModelMapper();
		FileEntity fileEntity = mapper.map(fileModel, FileEntity.class);
		fileEntity.setFile(fileModel.getFileContent());
		try {
			fileRepository.save(fileEntity);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new FileHandlerTechnicalException(e.getMessage());
		}
		fileModel = mapper.map(fileEntity, FileModel.class);
		return fileModel;
	}

	@Override
	public FileModel downloadFile(Long fileId) {
		FileModel fileModel = null;
		try {
			FileEntity fileEntity = fileRepository.findById(fileId).get();
			ModelMapper mapper = new ModelMapper();
			mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
			fileModel = mapper.map(fileEntity, FileModel.class);
			fileModel.setFileContent(fileEntity.getFile());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new FileHandlerTechnicalException(e.getMessage());
		}
		return fileModel;
	}

	@Override
	public FileModel deleteFile(Long fileId) {
		FileModel fileModel = new FileModel();
		try {
			FileEntity fileEntity = fileRepository.getOne(fileId);
			fileModel.setId(fileEntity.getId());
			fileModel.setFileName(fileEntity.getFileName());
			fileRepository.delete(fileEntity);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new FileHandlerTechnicalException(e.getMessage());
		}
		return fileModel;
	}

	private ModelMapper getModelMapper() {
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
		return mapper;
	}
}
