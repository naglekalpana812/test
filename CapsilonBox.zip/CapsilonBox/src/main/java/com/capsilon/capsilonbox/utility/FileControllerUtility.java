package com.capsilon.capsilonbox.utility;

import java.io.IOException;
import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.capsilon.capsilonbox.model.FileModel;

@Component
public class FileControllerUtility {
	public void getFileModel(MultipartFile file, FileModel fileModel) throws IOException {
		fileModel.setFileContent(file.getBytes());
		fileModel.setFileName(file.getOriginalFilename());
		fileModel.setFileSize(file.getSize());
		fileModel.setFormat(file.getContentType());
		fileModel.setSysCreationDate(new Date());
		fileModel.setUploadedBy("user");
	}
}