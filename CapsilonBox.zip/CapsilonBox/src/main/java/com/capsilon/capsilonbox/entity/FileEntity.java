package com.capsilon.capsilonbox.entity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "File_details")
public class FileEntity {

	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="file_name", nullable = false, length = 30)
	private String fileName;
	
	@Column(name = "sys_creation_date",nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date sysCreationDate;
	
	@Column(name = "sys_update_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date sysUpdateDate;
	
	@Column(name = "uploaded_by", nullable = false, length = 30)
	private String uploadedBy;
	
	@Column(name="file_content", nullable = false)
	@Lob @Basic(fetch = FetchType.LAZY)
	private byte[] file;
	
	@Column(name = "file_format", length = 20, nullable = true)
	private String format;
	
	@Column(name = "file_size", length=5, nullable = false)
	private long fileSize;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getSysCreationDate() {
		return sysCreationDate;
	}

	public void setSysCreationDate(Date sysCreationDate) {
		this.sysCreationDate = sysCreationDate;
	}

	public Date getSysUpdateDate() {
		return sysUpdateDate;
	}

	public void setSysUpdateDate(Date sysUpdateDate) {
		this.sysUpdateDate = sysUpdateDate;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] fileContent) {
		this.file = fileContent;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	
	
}
