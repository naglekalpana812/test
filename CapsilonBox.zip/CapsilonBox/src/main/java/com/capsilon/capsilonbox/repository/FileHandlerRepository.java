package com.capsilon.capsilonbox.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capsilon.capsilonbox.entity.FileEntity;

public interface FileHandlerRepository extends JpaRepository<FileEntity, Long> {

}
