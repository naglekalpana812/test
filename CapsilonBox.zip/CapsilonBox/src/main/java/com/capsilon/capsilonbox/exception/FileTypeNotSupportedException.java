package com.capsilon.capsilonbox.exception;

public class FileTypeNotSupportedException extends RuntimeException {

	private String message;
	public FileTypeNotSupportedException(String message) {
		this.message= message;
	}
	
	
	@Override
	public synchronized Throwable getCause() {
		return super.getCause();
	}

	@Override
	public String getLocalizedMessage() {
		return super.getLocalizedMessage();
	}

	@Override
	public String getMessage() {
		return message;
	}

	
	
}
