package com.capsilon.capsilonbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapsilonBoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapsilonBoxApplication.class, args);
	}

}
