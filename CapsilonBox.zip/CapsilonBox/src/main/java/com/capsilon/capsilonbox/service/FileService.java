package com.capsilon.capsilonbox.service;

import com.capsilon.capsilonbox.model.FileModel;

public interface FileService {
	public FileModel uploadFile(FileModel fileModel);
	public FileModel downloadFile(Long fileId);
	public FileModel deleteFile(Long fileId);
}
