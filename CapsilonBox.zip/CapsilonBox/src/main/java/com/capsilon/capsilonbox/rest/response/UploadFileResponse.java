package com.capsilon.capsilonbox.rest.response;

public class UploadFileResponse {

	private String fileName;
	private String fileDownloadUri;
	private String fileFormat;
	private long size;

	public UploadFileResponse(String fileName, String fileDownloadUri, String fileFormat, long size) {
		this.fileFormat=fileFormat;
		this.fileDownloadUri=fileDownloadUri;
		this.fileName=fileName;
		this.size=size;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileDownloadUri() {
		return fileDownloadUri;
	}

	public void setFileDownloadUri(String fileDownloadUri) {
		this.fileDownloadUri = fileDownloadUri;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}
	
}
