package com.capsilon.capsilonbox.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.capsilon.capsilonbox.exception.FileHandlerTechnicalException;
import com.capsilon.capsilonbox.exception.FileTypeNotSupportedException;
import com.capsilon.capsilonbox.model.FileModel;
import com.capsilon.capsilonbox.rest.response.UploadFileResponse;
import com.capsilon.capsilonbox.service.FileService;
import com.capsilon.capsilonbox.utility.FileControllerUtility;

@RestController
@RequestMapping("/file")
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);

	@Autowired
	private FileService fileService;

	@Autowired
	private FileControllerUtility fileControllerUtility;
	
	@PostMapping(value="/uploadFile")
	public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) {
		FileModel fileModel = new FileModel();
		try {
			if(file.getContentType().equals("application/pdf") 
					|| file.getContentType().equals("application/jpg") 
					|| file.getContentType().equals("application/jpeg")) {
			fileControllerUtility.getFileModel(file, fileModel);
			fileModel = fileService.uploadFile(fileModel);
			}else {
				logger.error("file format should be jpeg/pdf");
				throw new FileTypeNotSupportedException("file format should be jpeg/pdf");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new FileHandlerTechnicalException(e.getMessage());
		}

		String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
				.path(fileModel.getId().toString()).toUriString();
		
		return new UploadFileResponse(fileModel.getFileName(), fileDownloadUri, file.getContentType(), file.getSize());
	}

	@GetMapping("/downloadFile/{fileId}")
	public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId) {
		// Load file as Resource
		FileModel fileModel = fileService.downloadFile(fileId);

		return ResponseEntity.ok().contentType(MediaType.parseMediaType(fileModel.getFormat()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileModel.getFileName() + "\"")
				.body(new ByteArrayResource(fileModel.getFileContent()));
	}

	@DeleteMapping("/deleteFile/{fileId}")
	public ResponseEntity<String> deleteFile(@PathVariable Long fileId){
		FileModel fileModel = fileService.deleteFile(fileId);
		return ResponseEntity.ok(fileModel.getFileName() + " File deleted");
	}

	public FileService getFileService() {
		return fileService;
	}

	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}

	public FileControllerUtility getFileControllerUtility() {
		return fileControllerUtility;
	}

	public void setFileControllerUtility(FileControllerUtility fileControllerUtility) {
		this.fileControllerUtility = fileControllerUtility;
	}
	
	
}
